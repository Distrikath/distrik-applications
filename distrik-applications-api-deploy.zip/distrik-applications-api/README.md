# Distrik — Job Applications API

Stores job applications from your careers form and powers the **Applications**
screen in the Distrik dashboard (Settings → Recruitment · Applications).

Node + Express + SQLite. One small server, one database file.

---

## What you need
- A place to run Node (Render, Railway, or any VPS).
- Your dashboard (the `.html` file) open in a browser.

---

## Option A — Render (one click, recommended)

1. Put this folder in a GitHub repo (or use Render's "Deploy from a folder").
2. Render → **New → Blueprint** → pick the repo. It reads `render.yaml` and creates
   the web service **with a 1 GB disk** (so the database survives restarts).
3. When it asks, let it **generate `API_KEY`** (already set in the blueprint). After
   deploy, open the service → **Environment** → copy the `API_KEY` value.
4. Copy the service URL (e.g. `https://distrik-applications-api.onrender.com`).
5. In the dashboard → **Settings → Recruitment · Applications**:
   - **API Base URL** = the service URL
   - **API Key** = the generated key
   - **Test Connection** → should show ✓ → **Save Connection**.

> Note: a disk requires Render's **Starter** plan (paid). On the free tier the disk
> resets, so applications would be lost on redeploy.

## Option B — Railway

1. Railway → **New Project → Deploy from repo** (or upload this folder).
2. Add a **Volume** mounted at `/data`.
3. **Variables**: `API_KEY` = a strong secret (run `openssl rand -hex 32`),
   `DB_PATH` = `/data/applications.db`, `ALLOWED_ORIGINS` = blank.
4. Copy the public URL + the key into the dashboard (same as Render step 5).

## Option C — Your own VPS

```bash
npm install
cp .env.example .env        # set API_KEY, DB_PATH, ALLOWED_ORIGINS
npm start                   # runs on PORT (default 3001)
```
Put it behind nginx/Caddy with HTTPS, then connect the dashboard.

---

## Connect the careers form
Update your `apply.html` submit to POST to `<your-server>/api/applications`
using `apply-submit-snippet.js` (it also keeps the Formspree email as a backup).

## Generate a key
```bash
openssl rand -hex 32
```
Use the same value as the server's `API_KEY` and the dashboard's **API Key** field.

## Endpoints (auth via `X-API-Key` header, except POST)
| Method | Path | Use |
|---|---|---|
| POST   | /api/applications      | submit (public — from the careers form) |
| GET    | /api/applications      | list (filters: position, status, sort) |
| GET    | /api/applications/:id  | one |
| PATCH  | /api/applications/:id  | update status / rating / notes |
| DELETE | /api/applications/:id  | delete |
